# boids

interactive 2d flocking simulation with many customizable parameters

don't judge the code quality i don't know what i was doing
